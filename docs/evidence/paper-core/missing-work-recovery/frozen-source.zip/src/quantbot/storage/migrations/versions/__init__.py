"""QuantBot storage schema revisions."""
