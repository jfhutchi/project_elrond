"""Composition root: build the real paper-trading system from environment settings.

Everything above this module is deliberately dependency-injected and side-effect free.
This is the one place where concrete transports, credentials, and filesystem paths are
bound together, so a single import graph produces the runnable application.
"""

from __future__ import annotations

import argparse
import asyncio
import os
import signal
import subprocess
import threading
from collections.abc import Mapping
from dataclasses import dataclass, field
from datetime import UTC, date, datetime, timedelta
from decimal import Decimal
from pathlib import Path
from types import FrameType

from pydantic import SecretStr

from quantbot.anomaly.news import AlpacaNewsSource
from quantbot.backtest import BacktestEngine, BenchmarkVariant
from quantbot.brokers import AlpacaPaperBrokerAdapter, BrokerError, HttpxBrokerTransport
from quantbot.cli import CLIContext, CommandHandler
from quantbot.config import Settings, validate_trading_safety
from quantbot.domain import (
    Bar,
    OrderIntent,
    OrderSide,
    OrderType,
    ReconciliationStatus,
    StrategyIdentity,
    TimeInForce,
)
from quantbot.domain.ids import build_client_order_id
from quantbot.execution import ExecutionCoordinator, StartupRecovery
from quantbot.market_data import (
    CRYPTO_ADJUSTMENT,
    AdjustmentMode,
    AlpacaCryptoDataClient,
    AlpacaMarketCalendar,
    AlpacaMarketDataClient,
    HttpxMarketDataTransport,
    MarketDataCache,
    MarketDataError,
    MarketDataFeed,
)
from quantbot.operations import (
    AdaptiveMomentumRunner,
    CachedSessionCalendar,
    CryptoSessionCalendar,
    DaemonRunner,
    DataFreshness,
    HealthInputs,
    KillSwitchController,
    LedgerSyncingRecovery,
    MarketDataSettings,
    MarketDataSync,
    MeasuredReadiness,
    OperationalMetrics,
    QualificationTracker,
    ReadinessEvidence,
    RunOnceCycle,
    SessionCalendar,
    SessionObserver,
    StrategyDataError,
    WakeKind,
    evaluate_operational_health,
    measure_readiness,
)
from quantbot.operations.checkout import running_checkout_commit
from quantbot.operations.deployment import RuntimeContext, RuntimeRole
from quantbot.operations.protection import (
    PositionProtectionDaemonRunner,
    PositionProtectionSupervisor,
)
from quantbot.reporting import (
    ProjectStatusContext,
    WeeklyReportRequest,
    build_project_status,
    build_weekly_report,
)
from quantbot.risk import (
    OrderPurpose,
    build_veto_inputs,
    calculate_drawdown,
    evaluate_portfolio_vetoes,
)
from quantbot.risk.exposure import load_exposure_classification
from quantbot.risk.policy_versions import PolicySource, PolicyVersion, active_policy_version
from quantbot.storage import Database, StateConflictError, StorageRepository
from quantbot.storage.target import DatabaseTarget, resolve_database_target
from quantbot.strategy import (
    StrategyConfig,
    build_strategy_identity,
    load_strategy_config,
    strategy_id_for,
)

DEFAULT_CONFIG_PATH = "config/strategy-v1.yaml"
DEFAULT_DATABASE_PATH = "quantbot.db"
DEFAULT_LOCK_PATH = "quantbot.lock"
DEFAULT_REPORTS_DIR = "reports"
DEFAULT_MAX_DATA_AGE_SECONDS = 86_400
CREDENTIALS_MISSING = "PAPER_CREDENTIALS_NOT_CONFIGURED"

#: When this interpreter started, captured at import so every observation from one process
#: reports the same start. Read from the clock rather than the OS process table: `psutil` is not
#: a dependency and the exact boot instant does not matter -- what matters is that two
#: coordinators on one host get two different instance ids, and two imports cannot share one.
PROCESS_STARTED_AT = datetime.now(UTC)


class RuntimeConfigurationError(RuntimeError):
    """Raised when the process environment cannot produce a runnable system."""


@dataclass(frozen=True, slots=True)
class RuntimePaths:
    config: Path
    #: The SQLite path, kept for every caller that legitimately needs a file -- backups and the
    #: console's disk checks. `target` is the backend-neutral form (#196); this stays because
    #: SQLite is the only enabled backend and making a hundred call sites pretend otherwise
    #: would be ceremony, not portability.
    database: Path
    #: Where the store is, without assuming a filesystem. Resolving both from one call means a
    #: caller cannot end up with a path and a target that disagree.
    target: DatabaseTarget
    lock: Path
    #: Separate from the writer lock: this excludes a second scheduler, while the
    #: writer lock excludes a second writer and is held only during a cycle.
    daemon_lock: Path
    #: Held by the independently deployed after-entry protection loop only.
    protection_lock: Path
    reports: Path


def _env_path(name: str, default: str) -> Path:
    return Path(os.environ.get(name, default))


def runtime_paths() -> RuntimePaths:
    # `resolve_database_target` reads both variables and refuses the ambiguous case, so a
    # process cannot start against a store it was only half told about (#196). It raises the
    # typed `DatabaseTargetError`; nothing here catches it, because a misconfigured location is
    # exactly the condition that must stop a runtime rather than be worked around.
    target = resolve_database_target(default_path=DEFAULT_DATABASE_PATH)
    # Refused here rather than at the first `Database(...)`, so a disabled backend stops the
    # process with its own message instead of surfacing later as a path that does not exist.
    # There is deliberately no fallback: quietly using SQLite when someone configured
    # PostgreSQL is #86's empty-healthy-store failure with a different cause.
    target.require_enabled()
    return RuntimePaths(
        config=_env_path("QUANTBOT_CONFIG", DEFAULT_CONFIG_PATH),
        database=target.path,
        target=target,
        lock=_env_path("QUANTBOT_LOCK_PATH", DEFAULT_LOCK_PATH),
        daemon_lock=_env_path("QUANTBOT_LOCK_PATH", DEFAULT_LOCK_PATH).with_suffix(
            ".daemon.lock"
        ),
        protection_lock=_env_path("QUANTBOT_LOCK_PATH", DEFAULT_LOCK_PATH).with_suffix(
            ".protection.lock"
        ),
        reports=_env_path("QUANTBOT_REPORTS_DIR", DEFAULT_REPORTS_DIR),
    )


def market_data_settings() -> MarketDataSettings:
    return MarketDataSettings(
        feed=MarketDataFeed(os.environ.get("QUANTBOT_MARKET_DATA_FEED", MarketDataFeed.IEX.value)),
        adjustment=AdjustmentMode(
            os.environ.get("QUANTBOT_MARKET_DATA_ADJUSTMENT", AdjustmentMode.ALL.value)
        ),
    )


def max_data_age_seconds() -> int:
    raw = os.environ.get("QUANTBOT_MAX_DATA_AGE_SECONDS", str(DEFAULT_MAX_DATA_AGE_SECONDS))
    age = int(raw)
    if age <= 0:
        raise RuntimeConfigurationError("QUANTBOT_MAX_DATA_AGE_SECONDS must be positive")
    return age


def resolve_git_commit() -> str:
    """Return the deployed commit, preferring an explicit environment pin."""
    pinned = os.environ.get("QUANTBOT_GIT_COMMIT", "").strip()
    if pinned:
        return pinned
    try:
        completed = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            check=True,
            text=True,
            timeout=15,
        )
    except (OSError, subprocess.SubprocessError) as error:
        raise RuntimeConfigurationError(
            "cannot determine the deployed git commit; set QUANTBOT_GIT_COMMIT"
        ) from error
    return completed.stdout.strip()


def paper_credentials(settings: Settings) -> tuple[SecretStr, SecretStr]:
    key = settings.ALPACA_PAPER_API_KEY
    secret = settings.ALPACA_PAPER_API_SECRET
    if key is None or secret is None or not key.get_secret_value() or not secret.get_secret_value():
        raise RuntimeConfigurationError(CREDENTIALS_MISSING)
    return key, secret


def load_or_create_identity(
    database: Database,
    config: StrategyConfig,
    *,
    now: datetime,
) -> StrategyIdentity:
    """Reuse the immutable deployment identity so restarts never re-version a strategy."""
    strategy_id = strategy_id_for(config)
    with database.transaction() as session:
        stored = StorageRepository(session).get_strategy_deployment(strategy_id, config.version)
    if stored is not None:
        return stored
    identity = build_strategy_identity(
        config,
        git_commit=resolve_git_commit(),
        deployment_timestamp=now,
    )
    with database.transaction() as session:
        StorageRepository(session).save_strategy_deployment(identity)
    _enter_promotion_ladder(database, identity, now=now)
    return identity


def _enter_promotion_ladder(
    database: Database, identity: StrategyIdentity, *, now: datetime
) -> None:
    """Put a newly deployed strategy on the promotion ladder at `CANDIDATE`.

    `PromotionLedger` was called by nothing outside its own tests, so no strategy was ever on the
    ladder in a real store. A strategy that is not on the ladder cannot be reasoned about by any
    of the gates that judge it, and the console reads `list_promotions()` directly -- so the
    absence showed up as an empty panel rather than as an error.

    `CANDIDATE` claims nothing. `enter()` refuses an economic stage outright, precisely so that
    getting onto the ladder can never be mistaken for having earned a position on it: every
    economic stage is reached through `promote()`, which reads the forward ledger.

    Deliberately only entry. Automatic promotion is a separate decision, recorded on #46: a
    promoter written before any forward evidence exists could only be tested against fixtures,
    which is the condition that produced this defect class nine times over.

    Idempotent by refusal. `enter()` rejects a strategy already on the ladder rather than
    upserting, because re-entering would discard everything it had earned through the same call
    that legitimately starts one. A restart re-uses the stored identity and never reaches here,
    but a store that somehow has the position already must not be reset by a deployment.
    """
    from quantbot.research.promotion import (
        PromotionLedger,
        PromotionRefused,
        PromotionState,
        Stage,
    )

    try:
        with database.transaction() as session:
            PromotionLedger(session).enter(
                PromotionState(
                    strategy_id=identity.strategy_id,
                    stage=Stage.CANDIDATE,
                    strategy_version=identity.version,
                    configuration_hash=identity.configuration_hash,
                    reason="deployed; entering the ladder at the stage that claims nothing",
                    actor="runtime",
                    updated_at=now,
                )
            )
    except PromotionRefused:
        # Already on the ladder. Not an error: the strategy is where it should be, and this call
        # exists to establish that rather than to move it.
        return


@dataclass(slots=True)
class Runtime:
    """Every concrete collaborator the operational commands need."""

    settings: Settings
    config: StrategyConfig
    identity: StrategyIdentity
    paths: RuntimePaths
    database: Database
    broker: AlpacaPaperBrokerAdapter
    market_data: AlpacaMarketDataClient | AlpacaCryptoDataClient
    #: The data identity this runtime was actually wired with. Deriving the provider key
    #: from the environment instead would resolve a crypto runtime to the equity key and
    #: silently find no bars.
    market_data_config: MarketDataSettings
    sessions: SessionCalendar
    data_sync: MarketDataSync
    strategy: AdaptiveMomentumRunner
    recovery: LedgerSyncingRecovery
    coordinator: ExecutionCoordinator
    metrics: OperationalMetrics
    broker_transport: HttpxBrokerTransport
    data_transport: HttpxMarketDataTransport
    #: The recorded rule this process is running under (#82), resolved once at wiring time so
    #: every collaborator evaluates against the same version and the identity written into a
    #: refusal is the identity of the policy that actually produced it.
    veto_version: PolicyVersion
    #: Whether that version was read from the store or written as version 1 on first sight.
    veto_source: PolicySource
    # Captured once; later checkout/environment changes cannot relabel this interpreter.
    running_git_commit: str = field(default_factory=running_checkout_commit)

    def protector(self) -> PositionProtectionSupervisor:
        """Build the after-entry authority without a strategy, model, or research collaborator."""
        expected_account_id = self.settings.EXPECTED_ACCOUNT_ID
        if expected_account_id is None:
            raise RuntimeConfigurationError(
                "position protection requires EXPECTED_ACCOUNT_ID"
            )
        return PositionProtectionSupervisor(
            database=self.database,
            broker=self.broker,
            expected_account_id=expected_account_id,
            strategy_identity=self.identity,
            metrics=self.metrics,
            submitter=self.coordinator,
        )

    def observer(self) -> SessionObserver:
        """The market-hours pass. Deliberately built without a submitter or a strategy runner.

        Compare `cycle()` directly above: it takes `submitter=self.coordinator` and
        `strategy=self.strategy`, and this takes neither. That difference is the safety property,
        not a comment about one -- there is no route from an observation to an order.
        """
        return SessionObserver(
            database=self.database,
            recovery=self.recovery,
            data_sync=self.data_sync,
            kill_switch=KillSwitchController(self.database),
            metrics=self.metrics,
            max_data_age_seconds=max_data_age_seconds(),
        )

    def runtime_context(self) -> RuntimeContext:
        """What this process is, for the deployed-state record (#190).

        Built here because this is the layer that owns the settings and the opened database. The
        persisted store identity comes from that exact database, so a cycle cannot describe a
        different store from the one it writes to.
        """
        return RuntimeContext(
            role=RuntimeRole.COORDINATOR,
            store_identity=self.database.store_identity,
            trading_mode=self.settings.TRADING_MODE.value,
            process_started_at=PROCESS_STARTED_AT,
            git_commit=self.running_git_commit,
        )

    def cycle(self) -> RunOnceCycle:
        return RunOnceCycle(
            database=self.database,
            lock_path=self.paths.lock,
            strategy_identity=self.identity,
            recovery=self.recovery,
            data_sync=self.data_sync,
            strategy=self.strategy,
            submitter=self.coordinator,
            metrics=self.metrics,
            max_data_age_seconds=max_data_age_seconds(),
            runtime=self.runtime_context(),
        )

    async def aclose(self) -> None:
        await self.broker_transport.aclose()
        await self.data_transport.aclose()


def build_runtime(
    settings: Settings | None = None,
    *,
    database: Database | None = None,
    now: datetime | None = None,
) -> Runtime:
    """Bind credentials, transports, storage, and policies into one runnable system."""
    active_settings = settings or Settings()
    paths = runtime_paths()
    config = load_strategy_config(paths.config)
    key, secret = paper_credentials(active_settings)
    active_database = database or Database(paths.database)
    identity = load_or_create_identity(
        active_database,
        config,
        now=now or datetime.now(UTC),
    )

    broker_transport = HttpxBrokerTransport()
    data_transport = HttpxMarketDataTransport()
    broker = AlpacaPaperBrokerAdapter(
        api_key=key,
        api_secret=secret,
        transport=broker_transport,
    )
    # The calendar the strategy declares selects both its data source and its session model.
    # Crypto has no calendar to fetch and no feed or adjustment to choose, so pairing them
    # here keeps the provider key that identifies cached bars truthful for either market.
    if config.calendar == "CRYPTO24":
        market_data: AlpacaMarketDataClient | AlpacaCryptoDataClient = AlpacaCryptoDataClient(
            api_key=key, api_secret=secret, transport=data_transport
        )
        sessions: SessionCalendar = CryptoSessionCalendar()
        settings_for_data = MarketDataSettings(
            feed=MarketDataFeed.CRYPTO,
            adjustment=CRYPTO_ADJUSTMENT,
            provider=AlpacaCryptoDataClient.provider,
        )
    else:
        market_data = AlpacaMarketDataClient(
            api_key=key, api_secret=secret, transport=data_transport
        )
        sessions = CachedSessionCalendar(
            AlpacaMarketCalendar(api_key=key, api_secret=secret, transport=data_transport)
        )
        settings_for_data = market_data_settings()
    # #82. The rule the runtime enforces is the *recorded* one. Constructing
    # `PortfolioVetoPolicy()` here instead -- which is what this did -- meant every applied change
    # produced a correct, fully audited version history that changed nothing about what the
    # system does. On first run the shipped defaults are written as version 1 rather than assumed,
    # so refusals recorded before anyone opens a console still cite a version the history explains.
    with active_database.transaction() as session:
        veto_version, veto_source = active_policy_version(
            StorageRepository(session), now=datetime.now(UTC)
        )
    veto_policy = veto_version.policy()
    return Runtime(
        settings=active_settings,
        config=config,
        identity=identity,
        paths=paths,
        database=active_database,
        broker=broker,
        market_data=market_data,
        market_data_config=settings_for_data,
        sessions=sessions,
        data_sync=MarketDataSync(
            database=active_database,
            client=market_data,
            sessions=sessions,
            config=config,
            market_data=settings_for_data,
            veto_policy=veto_policy,
        ),
        strategy=AdaptiveMomentumRunner(
            database=active_database,
            broker=broker,
            config=config,
            identity=identity,
            sessions=sessions,
            market_data=settings_for_data,
            veto_policy=veto_policy,
            entry_buying_power_reserve_bps=active_settings.ENTRY_BUYING_POWER_RESERVE_BPS,
            # #56. Enrichment runs only for symbols that produced an anomaly, which is what the
            # routing gate's 98.24% search saving buys. Constructed here rather than defaulted
            # inside the runner: a source that built itself would be a second place credentials
            # are read, and the runner would have no way to be given a different one.
            catalyst_sources=(
                AlpacaNewsSource(data_transport, api_key=key, api_secret=secret),
            ),
        ),
        recovery=LedgerSyncingRecovery(
            active_database,
            broker,
            StartupRecovery(active_database, broker, active_settings),
        ),
        coordinator=ExecutionCoordinator(active_database, broker, active_settings),
        metrics=OperationalMetrics(),
        broker_transport=broker_transport,
        data_transport=data_transport,
        veto_version=veto_version,
        veto_source=veto_source,
    )


def _run_id(prefix: str, moment: datetime) -> str:
    return f"{prefix}-{moment.astimezone(UTC).strftime('%Y%m%dT%H%M%SZ')}"


def write_project_status(runtime: Runtime, *, next_priority: str) -> Path:
    """Refresh PROJECT_STATUS.md from durable evidence only, outside the checkout.

    It used to write `Path("PROJECT_STATUS.md")` -- a bare relative path, resolved against the
    process working directory, which for a deployed service is the repository. `PROJECT_STATUS.md`
    is tracked, so every successful cycle modified a version-controlled file inside the checkout.

    `operations/service.py` then refuses to start any component when
    `git status --porcelain --untracked-files=all` is non-empty. The two controls are mutually
    exclusive, and the deadlock is self-sustaining: once a cycle has written the file, nothing can
    make the tree clean again, so every later start is refused.

    That is not hypothetical. On the Omen, `Elrond Research` and `Elrond Ingestion` have been
    refused with `CHECKOUT_NOT_CLEAN` since 2026-09-12T15:15Z, which is why `research_tasks` is
    empty and no research cycle has ever run against the deployed store. The long-running daemon,
    console and protection services survive only because they started before the tree went dirty
    -- a restart would refuse them too, so the coordinator could not have come back from a reboot.

    The fix follows the rule the preflight already states as `EXTERNAL_STATE_REQUIRED`: generated
    state belongs outside the repository. `runtime.paths.reports` is already configured that way
    for exactly this class of artifact, and nothing reads this file programmatically, so moving it
    changes no other behaviour.
    """
    account_id = runtime.settings.EXPECTED_ACCOUNT_ID or "UNVERIFIED_ACCOUNT"
    status = build_project_status(
        runtime.database,
        ProjectStatusContext(
            settings=runtime.settings,
            strategy_id=runtime.identity.strategy_id,
            account_id=account_id,
            current_phase="PAPER_OBSERVATION",
            known_limitations=(
                "Fills are ingested from the broker REST ledger once per cycle; "
                "the push trade stream is not held open between cycles",
                "Four research cycles found no configuration of this strategy family that "
                "beats SPY buy-and-hold on risk-adjusted return; see docs/agent-runbook.md",
                "No untouched historical holdout remains; this account is now the only "
                "clean out-of-sample data available",
            ),
            research_underway=(
                "Exposure normalisation for asset-class sleeves (not yet pre-registered)",
            ),
            next_priority=next_priority,
            generated_at=datetime.now(UTC),
        ),
    )
    target = runtime.paths.reports / "PROJECT_STATUS.md"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(status.render_markdown(), encoding="utf-8")
    return target


async def _doctor(runtime: Runtime) -> dict[str, object]:
    health = await runtime.broker.health_check()
    sessions = await runtime.sessions.sessions()
    clock = await runtime.broker.get_market_clock()
    with runtime.database.transaction() as session:
        repository = StorageRepository(session)
        latest = repository.get_latest_reconciliation()
        kill_switch = repository.get_kill_switch_state()
    bars = tuple(bar.timestamp for bar in _durable_regime_bars(runtime))
    checked_at = datetime.now(UTC)
    completed_through = bars[-1] if bars else checked_at
    operational = evaluate_operational_health(
        HealthInputs(
            broker=health,
            data=DataFreshness(
                completed_through=min(completed_through, checked_at),
                checked_at=checked_at,
                max_age_seconds=max_data_age_seconds(),
            ),
            stream_connected=True,
            risk_healthy=True,
            reconciliation_status=(
                latest.status
                if latest is not None
                else ReconciliationStatus.RECONCILIATION_REQUIRED
            ),
            account_verified=(
                health.account_id is not None
                and health.account_id == runtime.settings.EXPECTED_ACCOUNT_ID
            ),
            kill_switch_engaged=kill_switch.engaged,
        )
    )
    write_project_status(runtime, next_priority="Resolve outstanding doctor reasons")
    return {
        "ok": operational.ready,
        "command": "doctor",
        "health": operational.safe_summary(),
        "reasons": list(operational.reasons),
        "calendar_sessions": len(sessions),
        "market_open": clock.is_open,
        "durable_regime_bars": len(bars),
        "safety": list(validate_trading_safety(runtime.settings, health.account_id).reasons),
    }


def _provider_key(runtime: Runtime) -> str:
    """The key identifying this runtime's cached bars, from what it was built with."""
    settings_for_data = runtime.market_data_config
    return MarketDataCache.provider_key(
        settings_for_data.provider,
        settings_for_data.feed,
        settings_for_data.adjustment,
        settings_for_data.timeframe,
    )


def _durable_regime_bars(runtime: Runtime) -> list[Bar]:
    with runtime.database.transaction() as session:
        return StorageRepository(session).list_bars(
            symbol=runtime.config.regime_symbol,
            provider=_provider_key(runtime),
        )


async def _sync_data(runtime: Runtime) -> dict[str, object]:
    result = await runtime.data_sync.sync()
    return {
        "ok": result.healthy and not result.stale_symbols,
        "command": "sync-data",
        "bars_stored": result.bars_stored,
        "completed_through": result.completed_through.isoformat(),
        "stale_symbols": list(result.stale_symbols),
        "reasons": list(result.reasons),
    }


async def _reconcile(runtime: Runtime) -> dict[str, object]:
    started_at = datetime.now(UTC)
    run_id = _run_id("reconcile", started_at)
    result = await runtime.recovery.recover(f"{run_id}:reconciliation", started_at=started_at)
    return {
        "ok": result.ready,
        "command": "reconcile",
        "status": result.reconciliation.status.value,
        "diff_count": len(result.reconciliation.diffs),
        "reasons": list(result.reasons),
        "unresolved_intents": list(result.unresolved_intent_ids),
    }


async def _run_once(runtime: Runtime, *, moment: datetime | None = None) -> dict[str, object]:
    started_at = moment or datetime.now(UTC)
    run_id = _run_id("run", started_at)
    runtime.strategy.bind_run(run_id)
    result = await runtime.cycle().run(
        run_id,
        started_at=started_at,
        trading_date=started_at.astimezone(UTC).date(),
    )
    write_project_status(
        runtime,
        next_priority=(
            "Accumulate paper observations toward the 30-day qualification window"
            if result.status == "SUCCEEDED"
            else f"Resolve cycle halt: {', '.join(result.reasons) or 'unknown'}"
        ),
    )
    return {
        "ok": result.status == "SUCCEEDED",
        "command": "run-once",
        "run_id": result.run_id,
        "status": result.status,
        "reasons": list(result.reasons),
        "signals_evaluated": result.signals_evaluated,
        "orders_submitted": result.orders_submitted,
    }


class _SignalStop:
    """Cooperative stop flag driven by SIGINT/SIGTERM."""

    def __init__(self) -> None:
        self._event = threading.Event()
        for name in ("SIGINT", "SIGTERM"):
            handled = getattr(signal, name, None)
            if handled is not None:
                signal.signal(handled, self._handle)

    def _handle(self, _signum: int, _frame: FrameType | None) -> None:
        self._event.set()

    def is_set(self) -> bool:
        return self._event.is_set()


async def _daemon(runtime: Runtime) -> dict[str, object]:
    observer = runtime.observer()

    async def cycle(moment: datetime, kind: WakeKind) -> object:
        """Dispatch on what the daemon woke up to do.

        An `OBSERVE` wake runs the authoritative safety checks and records a heartbeat. It cannot
        submit an order, because `observer` has nothing to submit through. A `CYCLE` wake is the
        after-close run, unchanged.
        """
        if kind is WakeKind.OBSERVE:
            clock = await runtime.broker.get_market_clock()
            return await observer.observe(now=moment, market_open=clock.is_open)
        return await _run_once(runtime, moment=moment)

    async def sleeper(delay: Decimal) -> None:
        await asyncio.sleep(max(float(delay), 0.0))

    result = await DaemonRunner(
        clock_provider=runtime.broker,
        cycle=cycle,
        sleeper=sleeper,
        metrics=runtime.metrics,
        lock_path=runtime.paths.daemon_lock,
    ).run(_SignalStop(), now=lambda: datetime.now(UTC))
    return {
        "ok": result.stopped_cleanly,
        "command": "daemon",
        "cycles_completed": result.cycles_completed,
    }


async def _protection_daemon(runtime: Runtime) -> dict[str, object]:
    """Run the after-entry supervisor as an independent process and liveness boundary."""
    protector = runtime.protector()

    async def evaluate(moment: datetime) -> object:
        return await protector.evaluate(now=moment)

    async def sleeper(delay: Decimal) -> None:
        await asyncio.sleep(max(float(delay), 0.0))

    result = await PositionProtectionDaemonRunner(
        clock_provider=runtime.broker,
        evaluate=evaluate,
        sleeper=sleeper,
        metrics=runtime.metrics,
        lock_path=runtime.paths.protection_lock,
    ).run(_SignalStop(), now=lambda: datetime.now(UTC))
    return {
        "ok": result.stopped_cleanly,
        "command": "protection-daemon",
        "cycles_completed": result.cycles_completed,
    }


def _backtest(runtime: Runtime, args: argparse.Namespace) -> dict[str, object]:
    provider_key = _provider_key(runtime)
    with runtime.database.transaction() as session:
        repository = StorageRepository(session)
        histories = {
            symbol: repository.list_bars(symbol=symbol, provider=provider_key)
            for symbol in runtime.config.universe
        }
    missing = sorted(symbol for symbol, bars in histories.items() if not bars)
    if missing:
        return {
            "ok": False,
            "command": "backtest",
            "reason": "DURABLE_BARS_MISSING",
            "symbols": missing,
        }
    engine = BacktestEngine(
        runtime.config,
        initial_cash=Decimal(str(getattr(args, "initial_cash", "100000"))),
    )
    requested = getattr(args, "variant", None)
    variants = (
        (BenchmarkVariant(requested),) if requested else tuple(BenchmarkVariant)
    )
    results = {
        variant.value: engine.run(histories, variant).metrics.model_dump(mode="json")
        for variant in variants
    }
    return {"ok": True, "command": "backtest", "results": results}


def _report_weekly(runtime: Runtime, args: argparse.Namespace) -> dict[str, object]:
    today = datetime.now(UTC).date()
    default_year, default_week, _ = (today - timedelta(days=7)).isocalendar()
    iso_year = int(getattr(args, "iso_year", None) or default_year)
    iso_week = int(getattr(args, "iso_week", None) or default_week)
    account_id = runtime.settings.EXPECTED_ACCOUNT_ID or "UNVERIFIED_ACCOUNT"
    report = build_weekly_report(
        runtime.database,
        WeeklyReportRequest(
            iso_year=iso_year,
            iso_week=iso_week,
            generated_at=datetime.now(UTC),
            strategy_id=runtime.identity.strategy_id,
            account_id=account_id,
        ),
    )
    target = runtime.paths.reports / "weekly" / f"{iso_year}-{iso_week:02d}.md"
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(report.render_markdown(), encoding="utf-8")
    return {
        "ok": True,
        "command": "report-weekly",
        "path": str(target),
        "observed_days": report.observed_days,
    }


async def _paper_smoke(runtime: Runtime) -> dict[str, object]:
    """Submit exactly one 1-share paper order to prove the order lifecycle end to end.

    Reached only after :func:`authorize_paper_smoke` has passed every safety gate and the
    operator supplied the exact one-shot acknowledgement. The acknowledgement is the risk
    approval for this single share; it is not a strategy signal and is recorded as such.
    """
    now = datetime.now(UTC)
    account = await runtime.broker.get_account()
    drawdown = calculate_drawdown(account.account.equity, None, runtime.config)
    signal_date = now.date()
    client_order_id = build_client_order_id(
        runtime.config.version,
        runtime.config.benchmark_symbol,
        signal_date,
        OrderSide.BUY,
        0,
    )
    intent = OrderIntent(
        intent_id=f"smoke-{client_order_id}",
        client_order_id=client_order_id,
        strategy_id=runtime.identity.strategy_id,
        signal_date=signal_date,
        symbol=runtime.config.benchmark_symbol,
        side=OrderSide.BUY,
        order_type=OrderType.MARKET,
        time_in_force=TimeInForce.DAY,
        quantity=Decimal("1"),
        created_at=now,
    )
    with runtime.database.transaction() as session:
        StorageRepository(session).create_incident(
            f"paper-smoke-{client_order_id}",
            severity="INFO",
            kind="PAPER_SMOKE_ORDER",
            message="Operator-acknowledged one-share paper smoke order",
            occurred_at=now,
            detail={"client_order_id": client_order_id, "quantity": "1"},
        )
    # The smoke order is an ENTRY, so the portfolio vetoes apply to it exactly as they do to a
    # strategy entry. The operator's acknowledgement is the *risk approval* for one share; it is
    # not an override of the portfolio limits, and a one-share order that breaches a daily loss
    # limit or trades on stale data is the order least worth forcing through.
    positions = await runtime.broker.get_positions()
    with runtime.database.transaction() as session:
        repository = StorageRepository(session)
        equity_marks = [
            (snapshot.captured_at, snapshot.equity)
            for snapshot in repository.list_equity_snapshots(
                account_id=account.account.account_id
            )
        ]
        stored_bars = repository.list_bars(symbol=runtime.config.benchmark_symbol)
        symbol_bars = [(bar.timestamp, bar.volume) for bar in stored_bars]
        # The last durable close, which is a price the decision could actually have seen.
        last_close = stored_bars[-1].close if stored_bars else None
    # The recorded policy this runtime resolved at wiring time, not a fresh construction of the
    # defaults -- otherwise the smoke path would judge an order against a rule the cycle is not
    # using, and report a veto decision citing an identity nothing enforced.
    policy = runtime.veto_version.policy()
    # `STALE_MARKET_DATA` judges the feed against the sessions the market completed rather than
    # against elapsed time (#74), so it needs the calendar. Without it the veto refuses, which is
    # correct and would silently stop the smoke path -- so it is fetched rather than defaulted.
    calendar_sessions = await runtime.sessions.sessions()
    # A held position's mark first, then the last stored close, then **nothing**. The first
    # version of this substituted `Decimal("0")` when the symbol was not held, which let a real
    # proposed entry contribute zero projected exposure while `NET_EXPOSURE` reported itself as
    # evaluated -- a fail-open inside the subsystem whose rule is that a missing risk input
    # rejects. Found by GPT-5.6 Sol reviewing #60. A missing price is now unmeasured, and the
    # veto refuses with `REFERENCE_PRICE_UNAVAILABLE`.
    reference = next(
        (position.market_price for position in positions if position.symbol == intent.symbol),
        None,
    )
    if reference is None:
        reference = last_close
    vetoes = evaluate_portfolio_vetoes(
        build_veto_inputs(
            symbol=intent.symbol,
            equity=account.account.equity,
            positions=positions,
            order_quantity=intent.quantity,
            order_price=reference,
            equity_marks=equity_marks,
            symbol_bars=symbol_bars,
            observed_at=now,
            volume_sessions=policy.minimum_volume_sessions,
            classification=load_exposure_classification(),
            sessions=calendar_sessions,
        ),
        policy,
    )
    result = await runtime.coordinator.submit(
        intent,
        purpose=OrderPurpose.ENTRY,
        market_eligible=True,
        drawdown=drawdown,
        risk_approved=True,
        vetoes=vetoes,
    )
    return {
        "ok": True,
        "command": "paper-smoke",
        "client_order_id": result.broker_order.client_order_id,
        "broker_order_id": result.broker_order.broker_order_id,
        "status": result.broker_order.status,
        "recovered_after_ambiguity": result.recovered_after_ambiguity,
    }


def _guarded(command: str, handler: CommandHandler) -> CommandHandler:
    """Report expected operational failures as structured output instead of a traceback.

    The durable fail-closed effects (kill switch, halted run, incident) have already been
    applied by the time these propagate; only the operator-facing rendering changes.
    """

    def guarded(args: argparse.Namespace) -> Mapping[str, object]:
        try:
            return handler(args)
        except (BrokerError, MarketDataError, StrategyDataError, StateConflictError) as error:
            return {
                "ok": False,
                "command": command,
                "reason": type(error).__name__,
                "detail": str(error),
            }

    return guarded


def build_cli_context(
    settings: Settings | None = None,
    *,
    runtime: Runtime | None = None,
) -> CLIContext:
    """Assemble the CLI context with every operational handler wired to real collaborators."""
    active = runtime or build_runtime(settings)
    raw: dict[str, CommandHandler] = {
        "doctor": lambda _args: asyncio.run(_doctor(active)),
        "sync-data": lambda _args: asyncio.run(_sync_data(active)),
        "reconcile": lambda _args: asyncio.run(_reconcile(active)),
        "run-once": lambda _args: asyncio.run(_run_once(active)),
        "daemon": lambda _args: asyncio.run(_daemon(active)),
        "protection-daemon": lambda _args: asyncio.run(_protection_daemon(active)),
        "backtest": lambda args: _backtest(active, args),
        "report-weekly": lambda args: _report_weekly(active, args),
        "paper-smoke": lambda _args: asyncio.run(_paper_smoke(active)),
    }
    handlers = {name: _guarded(name, handler) for name, handler in raw.items()}
    with active.database.transaction() as session:
        latest = StorageRepository(session).get_latest_reconciliation()
    reconciled = (
        latest is not None and latest.status is ReconciliationStatus.RECONCILED and not latest.diffs
    )
    async def _measure() -> MeasuredReadiness:
        """Probe the world at the moment somebody asks to resume trading.

        Deferred rather than computed when the context is built: readiness is a fact about
        *now*, and a value captured at process start would be minutes or hours stale by the
        time a clear is attempted. The broker round trip is the whole point, so it happens on
        demand.
        """
        return await measure_readiness(
            active.database,
            active.broker,
            paper_mode=active.settings.TRADING_MODE.value == "PAPER",
            expected_account_id=active.settings.EXPECTED_ACCOUNT_ID,
            # The sizing caps came from the strategy config, which means they parsed and
            # validated on the way in. That is what this condition actually establishes.
            risk_caps_valid=True,
            now=datetime.now(UTC),
        )

    return CLIContext(
        settings=active.settings,
        database=active.database,
        handlers=handlers,
        reported_account_id=active.settings.EXPECTED_ACCOUNT_ID,
        measure=_measure,
        clearance_evidence=ReadinessEvidence(
            paper_mode=active.settings.TRADING_MODE.value == "PAPER",
            account_verified=active.settings.EXPECTED_ACCOUNT_ID is not None,
            broker_healthy=active.settings.BROKER_HEALTHY,
            data_healthy=active.settings.MARKET_DATA_HEALTHY,
            risk_healthy=active.settings.RISK_ENGINE_HEALTHY,
            reconciliation_successful=reconciled,
        ),
    )


def qualification_tracker(runtime: Runtime) -> QualificationTracker:
    return QualificationTracker(runtime.database, runtime.identity.strategy_id)


def last_completed_iso_week(today: date) -> tuple[int, int]:
    year, week, _ = (today - timedelta(days=7)).isocalendar()
    return year, week
