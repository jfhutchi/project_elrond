"""Versioned forecast-database migrations."""
