import sys
sys.path.insert(0, "C:/Users/leepa/.codex/worktrees/paper-core-m0/project_elrond")
import pytest
from tests.fixtures.core_m3 import prepare
from quantbot.paper_core.activation import initialize_fixture_model, decision_model_objections
from quantbot.paper_core.trader import trader_cycle

@pytest.mark.asyncio
@pytest.mark.parametrize('commissioned', [False, True])
async def test_v2_commissioned_model_keeps_selection_and_posts(tmp_path, commissioned):
    db, store, broker, proof, observation, model, clocks = prepare(tmp_path)
    try:
        event = initialize_fixture_model(store, model, at=clocks.wall) if commissioned else None
        decision = await trader_cycle(store, broker, observation, model, proof, now=clocks.wall)
        with db.transaction() as session:
            objections = decision_model_objections(store, session, decision)
        print({'commissioned': commissioned, 'action': decision.action, 'gates': decision.gates,
               'time_evidence_id': decision.time_evidence_id,
               'activation_id': decision.activation_id, 'generation': decision.model_generation,
               'mode': decision.model_mode, 'model_objections': objections, 'posts': len(broker.posts)})
        assert decision.action == 'BUY', decision.gates
        if commissioned:
            assert decision.activation_id == event.id
            assert decision.model_generation == event.generation
        assert len(broker.posts) == 1
    finally:
        db.close()

